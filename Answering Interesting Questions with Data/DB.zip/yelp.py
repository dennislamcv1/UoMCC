import unittest
import sqlite3
import json
import os

def readDataFromFile(filename):
    ''' return the JSON data from the file with filename'''

    full_path = os.path.join(os.path.dirname(__file__), filename)
    f = open(full_path)
    file_data = f.read()
    f.close()
    json_data = json.loads(file_data)
    return json_data

def setUpDatabase(db_name):
    ''' set up the database, db_name, in the same directory '''

    path = os.path.dirname(os.path.abspath(__file__))
    conn = sqlite3.connect(path+'/'+db_name)
    cur = conn.cursor()
    return cur, conn

def setUpCategoriesTable(data, cur, conn):
    ''' Create the Categories table and add the data '''

    category_list = []
    for business in data['businesses']:
        business_categories = business['categories']
        for category in business_categories:
            if category['title'] not in category_list:
                category_list.append(category['title'])

    cur.execute("DROP TABLE IF EXISTS Categories")
    cur.execute("CREATE TABLE Categories (id INTEGER PRIMARY KEY, title TEXT)")
    for i in range(len(category_list)):
        cur.execute("INSERT INTO Categories (id,title) VALUES (?,?)",(i,category_list[i]))
    conn.commit()

def getCategoryId(category, cur):
    ''' given the restaurant category, return the id '''

    cur.execute('SELECT id from Categories WHERE title = ?',(category, ))
    cat_id = cur.fetchone()
    return cat_id[0]

def setUpRestaurantTable(data, cur, conn):
    ''' Finish the function setUpRestaurantTable
        Iterate through the JSON data to get a list of restaurants
        Load all of the restaurants into a database table called Restaurants, with the following columns in each row:
        restaurant_id (datatype: text; primary key)
        name (datatype: text)
        address (datatype: text)
        zip (datatype: text)
        category_id (datatype: integer)
        rating (datatype: real)
        price (datatype: text)'''

    pass

def getRestaurantsByPrice(price, cur, conn):
    ''' Return a list of tuples (name, address) for restaurants that match the price '''

    pass

def getRestaurantsByCategory(category, cur, conn):
    ''' Return a list of restuarant names that match the category '''

    pass

class TestAllMethods(unittest.TestCase):
    def setUp(self):
        path = os.path.dirname(os.path.abspath(__file__))
        self.conn = sqlite3.connect(path+'/'+'restaurants.db')
        self.cur = self.conn.cursor()
        self.data = readDataFromFile('yelp_data.txt')

    def test_businesses_table(self):
        self.cur.execute('SELECT * from Restaurants')
        resturant_list = self.cur.fetchall()
        self.assertEqual(len(resturant_list), 50)
        self.assertEqual(len(resturant_list[0]),7)
        self.assertIs(type(resturant_list[0][0]), str)
        self.assertIs(type(resturant_list[0][1]), str)
        self.assertIs(type(resturant_list[0][2]), str)
        self.assertIs(type(resturant_list[0][3]), str)
        self.assertIs(type(resturant_list[0][4]), int)
        self.assertIs(type(resturant_list[0][5]), float)
        self.assertIs(type(resturant_list[0][6]), str)

    def test_restaurants_by_price(self):
        x = sorted(getRestaurantsByPrice('$$$$', self.cur, self.conn))
        self.assertEqual(len(x),3)
        self.assertEqual(x[0][0],"Aamani's Smokehouse & Pizza")

        y = sorted(getRestaurantsByPrice('$$', self.cur, self.conn))
        self.assertEqual(y[0][0],"Anthony's Gourmet Pizza")
        self.assertEqual(len(getRestaurantsByPrice('$$', self.cur, self.conn)),29)

    def test_restaurants_by_category(self):
        e = sorted(getRestaurantsByCategory("Pizza", self.cur, self.conn))
        self.assertEqual(len(e), 20)
        self.assertEqual(e[0][0], "Anthony's Gourmet Pizza")
        f = getRestaurantsByCategory("Chicken Wings", self.cur, self.conn)
        self.assertEqual(len(f), 1)

def main():
    json_data = readDataFromFile('yelp_data.txt')
    cur, conn = setUpDatabase('restaurants.db')
    setUpCategoriesTable(json_data, cur, conn)
    setUpRestaurantTable(json_data, cur, conn)
    #out = getRestaurantsByPrice('$$$$', cur, conn)
    #print(out)
    #out = getRestaurantsByCategory("Chicken Wings", cur, conn)
    #print(out)

    #### FEEL FREE TO USE THIS SPACE TO TEST OUT YOUR FUNCTIONS

    conn.close()



if __name__ == "__main__":
    main()
    unittest.main(verbosity = 2)
