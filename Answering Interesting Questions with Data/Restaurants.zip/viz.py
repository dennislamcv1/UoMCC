from ctypes.wintypes import PFLOAT
import sqlite3
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import os

def access_database(db_name):
    '''
    This function takes in a db_file and returns the 
    database cursor and connection.
    '''
    path = os.path.dirname(os.path.abspath(__file__))
    conn = sqlite3.connect(path + '/' + db_name)
    cur = conn.cursor()
    return cur, conn

def num_category_bar_chart(cur, conn):
    '''
    This function creates a horizontal bar chart of the number of restaurants 
    in each category. The bar chart must have a title and axis labels.
    '''
    pass
  
def rating_vs_price_scatter_plot(cur, conn):
    '''
    This function creates a scatter plot of the rating for each restaurant versus its price.
    The scatter plot must have a title and axis labels.
    '''
    pass

def percentages_by_price_pie_chart(cur, conn, price_category):
    '''
    This function creates a pie chart with the percentage of restaurants by category for a given price category.
    The pie chart must have a title and labels on each section.
    '''
    pass

def main():
    '''
    This function sets up the database to access the data using access_database(db_file).
    Then, it calls the 3 visualization functions (num_restaurants_each_category_bar_chart,
    rating_vs_price_each_restaurant_scatter_plot, and restaurant_percentages_by_category_given_price_category_pie_chart).
    '''

    # get the cursor and connection
    cur, conn = access_database('restaurants.db')

    # create the plots
    num_category_bar_chart(cur, conn)
    rating_vs_price_scatter_plot(cur, conn)
    percentages_by_price_pie_chart(cur, conn, '$')
    percentages_by_price_pie_chart(cur, conn, '$$')
    percentages_by_price_pie_chart(cur, conn, '$$$')
    percentages_by_price_pie_chart(cur, conn, '$$$$')

main()